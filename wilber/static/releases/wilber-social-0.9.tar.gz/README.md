# wilber-plugin
Gimp Assets Sharing Plugin


copy wilber.py to ~/config/GIMP/2.10/plug-ins
