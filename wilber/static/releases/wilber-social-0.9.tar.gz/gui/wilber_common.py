# coding: utf-8
from __future__ import unicode_literals, print_function, division


ASSET_TYPE_TO_CATEGORY = {
    "brush": "brushes",
    "pattern": "patterns",
    "gradient": "gradients",
    "plug-in": "plug-ins",
    "palette": "palettes",
    "preset": "presets",

}
